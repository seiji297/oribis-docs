﻿$ErrorActionPreference = "Stop"
try {
    Set-Location 'C:\oribis-qa\oribis\e2e\wdio'
    $env:TAURI_WEBVIEW_AUTOMATION = "true"
    $env:ORIBIS_CLEAN_LAUNCH = "1"
    $env:ORIBIS_TEST_MODE = "1"
    $env:ORIBIS_WDIO_EVIDENCE_DIR = 'C:\oribis-qa\artifacts\20260705-211538\wdio-evidence'
    $env:ORIBIS_WDIO_ONBOARDING_PROVIDER = 'local_llm'



    $env:ORIBIS_WDIO_ONBOARDING_BASE_URL_LOCAL_LLM = 'http://127.0.0.1:11434'

    $env:ORIBIS_WDIO_ONBOARDING_MODEL_LOCAL_LLM = 'qwen2.5:3b-instruct'
    $env:ORIBIS_WDIO_REAL_LLM_MIN_PASS = '8'
    $wdioArgs = @('run', 'wdio.conf.ts', '--spec', 'tests\app-ai-native-real-llm-representative.spec.ts')
    # Native Tauri/tauri-driver stderr can contain legitimate runtime INFO logs.
    # Treat the native process exit code as authoritative and keep stderr as evidence.
    $ErrorActionPreference = "Continue"
    & 'C:\oribis-qa\oribis\e2e\wdio\node_modules\.bin\wdio.cmd' @wdioArgs > 'C:\oribis-qa\artifacts\20260705-211538\wdio.out.log' 2> 'C:\oribis-qa\artifacts\20260705-211538\wdio.err.log'
    $exitCode = if ($null -eq $LASTEXITCODE) { 0 } else { [int]$LASTEXITCODE }
    $ErrorActionPreference = "Stop"
    [pscustomobject]@{
        exitCode = $exitCode
        completedAt = (Get-Date).ToString("o")
    } | ConvertTo-Json -Depth 4 | Set-Content -Path 'C:\oribis-qa\artifacts\20260705-211538\wdio-interactive-result.json' -Encoding UTF8
    exit $exitCode
} catch {
    $_.Exception.Message | Set-Content -Path 'C:\oribis-qa\artifacts\20260705-211538\wdio-interactive-error.txt' -Encoding UTF8
    [pscustomobject]@{
        exitCode = 1
        completedAt = (Get-Date).ToString("o")
        error = $_.Exception.Message
    } | ConvertTo-Json -Depth 4 | Set-Content -Path 'C:\oribis-qa\artifacts\20260705-211538\wdio-interactive-result.json' -Encoding UTF8
    exit 1
}
