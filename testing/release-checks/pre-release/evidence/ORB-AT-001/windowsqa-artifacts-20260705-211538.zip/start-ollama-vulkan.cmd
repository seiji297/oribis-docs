set OLLAMA_HOST=127.0.0.1:11434
set OLLAMA_LLM_LIBRARY=vulkan
"C:\Users\admin\AppData\Local\Programs\Ollama\ollama.exe" serve > "C:\oribis-qa\artifacts\20260705-211538\ollama-vulkan-serve.log" 2>&1
