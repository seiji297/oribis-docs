﻿$ErrorActionPreference = "Stop"
try {
    Set-Location 'C:\oribis-qa\oribis-official\e2e\wdio'
    $env:TAURI_WEBVIEW_AUTOMATION = "true"
    $env:ORIBIS_CLEAN_LAUNCH = "1"
    $env:ORIBIS_TEST_MODE = "1"
    $env:ORIBIS_WDIO_EVIDENCE_DIR = 'C:\oribis-qa\artifacts\20260705-111317\wdio-evidence'
    $wdioArgs = @('run', 'wdio.conf.ts', '--spec', 'tests\tts-voice-playback.spec.ts')
    # Native Tauri/tauri-driver stderr can contain legitimate runtime INFO logs.
    # Treat the native process exit code as authoritative and keep stderr as evidence.
    $ErrorActionPreference = "Continue"
    & 'C:\oribis-qa\oribis-official\e2e\wdio\node_modules\.bin\wdio.cmd' @wdioArgs > 'C:\oribis-qa\artifacts\20260705-111317\wdio.out.log' 2> 'C:\oribis-qa\artifacts\20260705-111317\wdio.err.log'
    $exitCode = if ($null -eq $LASTEXITCODE) { 0 } else { [int]$LASTEXITCODE }
    $ErrorActionPreference = "Stop"
    [pscustomobject]@{
        exitCode = $exitCode
        completedAt = (Get-Date).ToString("o")
    } | ConvertTo-Json -Depth 4 | Set-Content -Path 'C:\oribis-qa\artifacts\20260705-111317\wdio-interactive-result.json' -Encoding UTF8
    exit $exitCode
} catch {
    $_.Exception.Message | Set-Content -Path 'C:\oribis-qa\artifacts\20260705-111317\wdio-interactive-error.txt' -Encoding UTF8
    [pscustomobject]@{
        exitCode = 1
        completedAt = (Get-Date).ToString("o")
        error = $_.Exception.Message
    } | ConvertTo-Json -Depth 4 | Set-Content -Path 'C:\oribis-qa\artifacts\20260705-111317\wdio-interactive-result.json' -Encoding UTF8
    exit 1
}
