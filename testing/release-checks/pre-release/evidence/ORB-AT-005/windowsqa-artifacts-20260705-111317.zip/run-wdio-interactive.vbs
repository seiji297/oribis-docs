Set shell = CreateObject("WScript.Shell")
shell.CurrentDirectory = "C:\oribis-qa\oribis-official\e2e\wdio"
shell.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -File ""C:\oribis-qa\artifacts\20260705-111317\run-wdio-interactive.ps1""", 0, True
