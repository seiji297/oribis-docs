﻿param(
    [string]$OutputPath,
    [string]$MetadataPath,
    [string]$ExpectedExe,
    [string]$ExpectedSha256,
    [string]$ErrorPath
)
$ErrorActionPreference = "Stop"
try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $processes = @(Get-Process -Name Oribis,oribis -ErrorAction SilentlyContinue | ForEach-Object {
        [pscustomobject]@{
            id = $_.Id
            processName = $_.ProcessName
            path = $_.Path
            mainWindowHandle = $_.MainWindowHandle.ToInt64()
            mainWindowTitle = $_.MainWindowTitle
            hasExited = $_.HasExited
        }
    })
    if ($processes.Count -eq 0) {
        throw "Oribis process was not found in interactive desktop session"
    }
    $bounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $OutputPath) | Out-Null
    $bitmap = New-Object System.Drawing.Bitmap $bounds.Width, $bounds.Height
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    try {
        $graphics.CopyFromScreen($bounds.Location, [System.Drawing.Point]::Empty, $bounds.Size)
        $bitmap.Save($OutputPath, [System.Drawing.Imaging.ImageFormat]::Png)
    } finally {
        $graphics.Dispose()
        $bitmap.Dispose()
    }
    [pscustomobject]@{
        capturedAt = (Get-Date).ToString("o")
        outputPath = $OutputPath
        expectedExe = $ExpectedExe
        expectedSha256 = $ExpectedSha256
        user = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
        host = $env:COMPUTERNAME
        bounds = [pscustomobject]@{
            x = $bounds.X
            y = $bounds.Y
            width = $bounds.Width
            height = $bounds.Height
        }
        processCount = $processes.Count
        processes = $processes
    } | ConvertTo-Json -Depth 6 | Set-Content -Path $MetadataPath -Encoding UTF8
} catch {
    $_.Exception.Message | Set-Content -Path $ErrorPath -Encoding UTF8
    exit 1
}
