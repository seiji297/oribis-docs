import { add } from './math/newMath.js';
export function addOne(value) { return add(value, 1); }