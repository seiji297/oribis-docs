export function add(a, b) { return a + b; }

// Contents of oldMath.js have been moved to here.