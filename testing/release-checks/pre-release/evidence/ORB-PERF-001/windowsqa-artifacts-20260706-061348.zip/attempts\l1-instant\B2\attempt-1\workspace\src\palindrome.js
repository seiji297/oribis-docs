export function isPalindrome(value) {
  const cleanedValue = value.replace(/[^a-zA-Z0-9]/gi, '').toLowerCase();
  return cleanedValue === cleanedValue.split('').reverse().join('');
}