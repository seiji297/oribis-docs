import { buildSummary } from '../src/longFile.js';

const args = process.argv.slice(2);
if (args.length !== 1) {
  console.error('Usage: node cli/greet.js --name <name>');
  process.exit(1);
}

const name = args[0].split('=')[1];
console.log(`Hello, ${name}!`);