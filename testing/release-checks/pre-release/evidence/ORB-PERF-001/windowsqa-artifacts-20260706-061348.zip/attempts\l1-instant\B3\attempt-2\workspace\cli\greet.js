import { execFileSync } from 'node:child_process';

if (process.argv.length !== 4) {
  console.error('Usage: node greet.js --name <name>');
  process.exit(1);
}

const name = process.argv[3];
console.log(`Hello, ${name}!`);