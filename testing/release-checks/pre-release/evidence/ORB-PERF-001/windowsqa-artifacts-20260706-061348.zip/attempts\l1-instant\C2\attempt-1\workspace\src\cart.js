import { formatCurrency } from '../money/formatCurrency.js';
export function totalLabel(total) { return formatCurrency(total); }