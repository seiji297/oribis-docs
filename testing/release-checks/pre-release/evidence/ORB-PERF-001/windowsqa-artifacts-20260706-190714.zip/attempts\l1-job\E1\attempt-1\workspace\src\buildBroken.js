export function pickName(user) { return user.fullName.toUpperCase(); }
