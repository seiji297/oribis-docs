import { formatCurrency } from './utils/format.js';
export function totalLabel(total) { return formatCurrency(total); }
