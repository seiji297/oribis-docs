import { shippingCost } from './shipping.js';
export function checkoutTotal(cart) { return cart.items.reduce((sum, item) => sum + item.price * item.quantity, 0) + shippingCost(cart); }
