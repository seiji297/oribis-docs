export function normalizeCustomer(input) { return { id: input.id, tier: input.tier || 'standard', active: input.active !== false }; }
