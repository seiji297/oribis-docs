export function discountRate(customer) {
  if (customer.tier === 'platinum') return 0.15;
  if (customer.tier === 'gold') return 0.05;
  return 0;
}
