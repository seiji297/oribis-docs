export const feature6 = 6;
