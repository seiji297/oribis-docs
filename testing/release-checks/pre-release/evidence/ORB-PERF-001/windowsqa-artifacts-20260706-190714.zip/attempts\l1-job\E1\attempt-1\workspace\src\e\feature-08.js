export const feature8 = 8;
