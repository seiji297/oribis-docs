export const feature24 = 24;
