export const feature32 = 32;
