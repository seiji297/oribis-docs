export const feature40 = 40;
