export const feature48 = 48;
