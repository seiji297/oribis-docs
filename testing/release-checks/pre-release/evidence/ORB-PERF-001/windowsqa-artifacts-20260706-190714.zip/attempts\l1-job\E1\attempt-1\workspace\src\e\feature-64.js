export const feature64 = 64;
