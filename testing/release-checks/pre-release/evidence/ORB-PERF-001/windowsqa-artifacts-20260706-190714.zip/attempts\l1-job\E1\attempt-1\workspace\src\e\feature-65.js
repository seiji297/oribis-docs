export const feature65 = 65;
