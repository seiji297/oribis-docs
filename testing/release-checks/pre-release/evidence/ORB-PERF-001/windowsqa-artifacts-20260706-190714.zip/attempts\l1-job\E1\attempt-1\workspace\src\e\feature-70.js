export const feature70 = 70;
