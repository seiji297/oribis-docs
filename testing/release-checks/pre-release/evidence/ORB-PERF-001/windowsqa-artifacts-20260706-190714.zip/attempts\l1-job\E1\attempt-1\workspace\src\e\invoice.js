import { discountRate } from './discounts.js';
export function invoiceTotal(customer, items) { const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0); return Math.round(subtotal * (1 - discountRate(customer))); }
