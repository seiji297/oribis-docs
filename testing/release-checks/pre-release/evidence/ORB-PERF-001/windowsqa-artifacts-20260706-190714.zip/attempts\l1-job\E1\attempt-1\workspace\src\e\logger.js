export function createLogger() { return { log(message) { return `[log] ${message}`; } }; }
