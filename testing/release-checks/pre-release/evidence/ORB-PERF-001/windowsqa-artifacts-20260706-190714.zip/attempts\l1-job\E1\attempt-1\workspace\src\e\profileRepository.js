export function getProfile(id) { return { id, name: 'Anima' }; }
