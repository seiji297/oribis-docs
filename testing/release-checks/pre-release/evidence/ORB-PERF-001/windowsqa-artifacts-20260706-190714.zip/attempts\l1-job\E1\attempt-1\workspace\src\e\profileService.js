import { getProfile } from './profileRepository.js';
export function profileLabel(id) { const profile = getProfile(id); return `${profile.id}:${profile.name}`; }
