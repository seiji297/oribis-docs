export async function fetchWithRetry(fetcher) { return fetcher(); }
