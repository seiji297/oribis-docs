import { createLogger } from './logger.js';
export function serviceMessage(name) { const logger = createLogger(); return logger.log(`service:${name}`); }
