export function shippingCost(cart) { return cart.expedited ? 0 : 0; }
