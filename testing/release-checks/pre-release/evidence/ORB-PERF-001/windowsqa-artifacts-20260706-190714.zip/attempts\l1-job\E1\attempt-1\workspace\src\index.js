import { add } from './math/oldMath.js';
export function addOne(value) { return add(value, 1); }
