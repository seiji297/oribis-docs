export function isPalindrome(value) { return false; }
