import { load } from './loader.js';
import { transform } from './transformer.js';
import { write } from './writer.js';
export function runPipeline() { return write(transform(load())); }
