export function transform(items) { return items.map((item) => item.toUpperCase()); }
