export function write(items) { return items.join(','); }
