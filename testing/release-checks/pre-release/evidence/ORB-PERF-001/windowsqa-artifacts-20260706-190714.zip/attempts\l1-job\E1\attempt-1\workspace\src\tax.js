export function formatTax(amount, rate) { return amount; }
