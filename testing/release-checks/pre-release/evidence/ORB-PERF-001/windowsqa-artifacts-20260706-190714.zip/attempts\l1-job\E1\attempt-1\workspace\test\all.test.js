await import('./palindrome.test.js');
await import('./calc.test.js');
await import('./tax.test.js');
