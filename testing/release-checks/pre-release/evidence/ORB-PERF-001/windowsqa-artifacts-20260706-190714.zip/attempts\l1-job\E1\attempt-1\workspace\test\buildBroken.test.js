import { pickName } from '../src/buildBroken.js';
if (pickName({ name: 'Anima' }) !== 'ANIMA') throw new Error('pickName');
