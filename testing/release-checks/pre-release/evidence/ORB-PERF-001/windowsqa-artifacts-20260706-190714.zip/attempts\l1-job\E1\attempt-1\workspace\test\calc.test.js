import { multiply } from '../src/calc.js';
if (multiply(6, 7) !== 42) throw new Error('multiply');
