import { totalLabel } from '../src/cart.js';
if (totalLabel(12) !== '$12.00') throw new Error('currency');
