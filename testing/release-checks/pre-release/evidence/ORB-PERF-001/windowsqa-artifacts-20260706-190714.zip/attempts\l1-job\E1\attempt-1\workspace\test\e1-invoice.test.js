import { normalizeCustomer } from '../src/e/customer.js';
import { invoiceTotal } from '../src/e/invoice.js';
const customer = normalizeCustomer({ id: 'c1', tier: 'platinum' });
if (invoiceTotal(customer, [{ price: 100, quantity: 2 }]) !== 170) throw new Error('platinum discount');
if (invoiceTotal(normalizeCustomer({ id: 'c2', tier: 'standard' }), [{ price: 25, quantity: 2 }]) !== 50) throw new Error('standard total');
