import { checkoutTotal } from '../src/e/checkout.js';
const cart = { expedited: true, items: [{ price: 20, quantity: 2 }] };
if (checkoutTotal(cart) !== 55) throw new Error('expedited shipping should add 15');
