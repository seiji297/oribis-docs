import { fetchWithRetry } from '../src/e/retry.js';
let calls = 0;
const value = await fetchWithRetry(async () => { calls += 1; if (calls < 3) throw new Error('temporary'); return 'ok'; }, { retries: 3 });
if (value !== 'ok') throw new Error('value');
if (calls !== 3) throw new Error(`calls ${calls}`);
