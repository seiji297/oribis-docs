import { createLogger } from '../src/e/logger.js';
import { serviceMessage } from '../src/e/service.js';
const logger = createLogger({ prefix: 'oribis' });
if (logger.info('ready') !== '[oribis] ready') throw new Error('logger info');
if (serviceMessage('worker') !== '[oribis] service:worker') throw new Error('service uses new logger');
