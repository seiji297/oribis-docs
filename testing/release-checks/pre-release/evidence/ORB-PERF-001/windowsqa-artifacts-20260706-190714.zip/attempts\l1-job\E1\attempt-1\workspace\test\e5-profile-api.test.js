import { profileLabel } from '../src/e/profileService.js';
const label = await profileLabel('u1');
if (label !== 'u1:Anima') throw new Error(label);
