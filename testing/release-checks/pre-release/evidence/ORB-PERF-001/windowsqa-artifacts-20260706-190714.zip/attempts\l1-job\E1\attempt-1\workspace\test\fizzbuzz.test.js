import { fizzBuzz } from '../src/fizzbuzz.js';
if (fizzBuzz(3) !== 'Fizz') throw new Error('3');
if (fizzBuzz(5) !== 'Buzz') throw new Error('5');
if (fizzBuzz(15) !== 'FizzBuzz') throw new Error('15');
if (fizzBuzz(2) !== '2') throw new Error('2');
