import { execFileSync } from 'node:child_process';
const out = execFileSync(process.execPath, ['cli/greet.js', '--name', 'Anima'], { encoding: 'utf8' }).trim();
if (out !== 'Hello, Anima!') throw new Error(out);
