import { add } from '../src/math/oldMath.js';
if (!(add(2, 3) === 5)) throw new Error('math');
