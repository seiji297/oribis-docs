import { isPalindrome } from '../src/palindrome.js';
if (!isPalindrome('level')) throw new Error('level');
if (!isPalindrome('A man, a plan, a canal: Panama')) throw new Error('phrase');
if (isPalindrome('oribis')) throw new Error('negative');
