import { formatTax } from '../src/tax.js';
if (formatTax(100, 0.1) !== 110) throw new Error('tax');
