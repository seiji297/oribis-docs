export function discountRate(customer) { return customer.tier === 'gold' ? 0.05 : 0; }
